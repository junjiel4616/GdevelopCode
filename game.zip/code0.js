gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDBridgeObjects1= [];
gdjs.Untitled_32sceneCode.GDBridgeObjects2= [];
gdjs.Untitled_32sceneCode.GDBridgeObjects3= [];
gdjs.Untitled_32sceneCode.GDShortRoofObjects1= [];
gdjs.Untitled_32sceneCode.GDShortRoofObjects2= [];
gdjs.Untitled_32sceneCode.GDShortRoofObjects3= [];
gdjs.Untitled_32sceneCode.GDVillageGateTopObjects1= [];
gdjs.Untitled_32sceneCode.GDVillageGateTopObjects2= [];
gdjs.Untitled_32sceneCode.GDVillageGateTopObjects3= [];
gdjs.Untitled_32sceneCode.GDBigWoodPlatform2Objects1= [];
gdjs.Untitled_32sceneCode.GDBigWoodPlatform2Objects2= [];
gdjs.Untitled_32sceneCode.GDBigWoodPlatform2Objects3= [];
gdjs.Untitled_32sceneCode.GDHouseTallBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDHouseTallBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDHouseTallBackgroundObjects3= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects3= [];
gdjs.Untitled_32sceneCode.GDHouseSmallBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDHouseSmallBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDHouseSmallBackgroundObjects3= [];
gdjs.Untitled_32sceneCode.GDHouseTallForegroundObjects1= [];
gdjs.Untitled_32sceneCode.GDHouseTallForegroundObjects2= [];
gdjs.Untitled_32sceneCode.GDHouseTallForegroundObjects3= [];
gdjs.Untitled_32sceneCode.GDHouseObjects1= [];
gdjs.Untitled_32sceneCode.GDHouseObjects2= [];
gdjs.Untitled_32sceneCode.GDHouseObjects3= [];
gdjs.Untitled_32sceneCode.GDBlackSpaceObjects1= [];
gdjs.Untitled_32sceneCode.GDBlackSpaceObjects2= [];
gdjs.Untitled_32sceneCode.GDBlackSpaceObjects3= [];
gdjs.Untitled_32sceneCode.GDCloudsObjects1= [];
gdjs.Untitled_32sceneCode.GDCloudsObjects2= [];
gdjs.Untitled_32sceneCode.GDCloudsObjects3= [];
gdjs.Untitled_32sceneCode.GDFullMoonObjects1= [];
gdjs.Untitled_32sceneCode.GDFullMoonObjects2= [];
gdjs.Untitled_32sceneCode.GDFullMoonObjects3= [];
gdjs.Untitled_32sceneCode.GDStarObjects1= [];
gdjs.Untitled_32sceneCode.GDStarObjects2= [];
gdjs.Untitled_32sceneCode.GDStarObjects3= [];
gdjs.Untitled_32sceneCode.GDKnightMaleObjects1= [];
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2= [];
gdjs.Untitled_32sceneCode.GDKnightMaleObjects3= [];
gdjs.Untitled_32sceneCode.GDShotgunObjects1= [];
gdjs.Untitled_32sceneCode.GDShotgunObjects2= [];
gdjs.Untitled_32sceneCode.GDShotgunObjects3= [];
gdjs.Untitled_32sceneCode.GDArrowObjects1= [];
gdjs.Untitled_32sceneCode.GDArrowObjects2= [];
gdjs.Untitled_32sceneCode.GDArrowObjects3= [];
gdjs.Untitled_32sceneCode.GDBossIconObjects1= [];
gdjs.Untitled_32sceneCode.GDBossIconObjects2= [];
gdjs.Untitled_32sceneCode.GDBossIconObjects3= [];
gdjs.Untitled_32sceneCode.GDBullet5Objects1= [];
gdjs.Untitled_32sceneCode.GDBullet5Objects2= [];
gdjs.Untitled_32sceneCode.GDBullet5Objects3= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDArrowObjects1Objects = Hashtable.newFrom({"Arrow": gdjs.Untitled_32sceneCode.GDArrowObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDArrowObjects1Objects = Hashtable.newFrom({"Arrow": gdjs.Untitled_32sceneCode.GDArrowObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKnightMaleObjects1Objects = Hashtable.newFrom({"KnightMale": gdjs.Untitled_32sceneCode.GDKnightMaleObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i].getY() > 1080 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i].setPosition(84,620);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDArrowObjects1Objects = Hashtable.newFrom({"Arrow": gdjs.Untitled_32sceneCode.GDArrowObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBossIconObjects1Objects = Hashtable.newFrom({"BossIcon": gdjs.Untitled_32sceneCode.GDBossIconObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet5Objects1Objects = Hashtable.newFrom({"Bullet5": gdjs.Untitled_32sceneCode.GDBullet5Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKnightMaleObjects1Objects = Hashtable.newFrom({"KnightMale": gdjs.Untitled_32sceneCode.GDKnightMaleObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet5Objects1Objects = Hashtable.newFrom({"Bullet5": gdjs.Untitled_32sceneCode.GDBullet5Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKnightMaleObjects1Objects = Hashtable.newFrom({"KnightMale": gdjs.Untitled_32sceneCode.GDKnightMaleObjects1});
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Untitled_32sceneCode.GDShotgunObjects1);
gdjs.Untitled_32sceneCode.GDArrowObjects1.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDShotgunObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDShotgunObjects1[i].getBehavior("FireBullet").Fire((gdjs.Untitled_32sceneCode.GDShotgunObjects1[i].getPointX("BulletPoint")), (gdjs.Untitled_32sceneCode.GDShotgunObjects1[i].getPointY("BulletPoint")), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDArrowObjects1Objects, (gdjs.Untitled_32sceneCode.GDShotgunObjects1[i].getAngle()), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.Untitled_32sceneCode.GDArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDArrowObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKnightMaleObjects1Objects, 2000, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDArrowObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDArrowObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shotgun"), gdjs.Untitled_32sceneCode.GDShotgunObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDShotgunObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDShotgunObjects1[i].setPosition((( gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[0].getPointX("Gun")),(( gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[0].getPointY("Gun")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDShotgunObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDShotgunObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.Untitled_32sceneCode.GDArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("BossIcon"), gdjs.Untitled_32sceneCode.GDBossIconObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDArrowObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBossIconObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDArrowObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBossIconObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBossIconObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBossIconObjects1[i].getBehavior("Health").Hit(10, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDArrowObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BossIcon"), gdjs.Untitled_32sceneCode.GDBossIconObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBossIconObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBossIconObjects1[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBossIconObjects1[k] = gdjs.Untitled_32sceneCode.GDBossIconObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBossIconObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBossIconObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBossIconObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBossIconObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BossIcon"), gdjs.Untitled_32sceneCode.GDBossIconObjects1);
gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects1);
gdjs.Untitled_32sceneCode.GDBullet5Objects1.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBossIconObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBossIconObjects1[i].getBehavior("FireBullet").FireTowardObject((gdjs.Untitled_32sceneCode.GDBossIconObjects1[i].getPointX("Fire")), (gdjs.Untitled_32sceneCode.GDBossIconObjects1[i].getPointY("Fire")), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet5Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKnightMaleObjects1Objects, 200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet5"), gdjs.Untitled_32sceneCode.GDBullet5Objects1);
gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet5Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDKnightMaleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBullet5Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i].getBehavior("Health").Hit(10, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBullet5Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBullet5Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("KnightMale"), gdjs.Untitled_32sceneCode.GDKnightMaleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[k] = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDKnightMaleObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDKnightMaleObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDBridgeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBridgeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBridgeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDShortRoofObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShortRoofObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShortRoofObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDVillageGateTopObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDVillageGateTopObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDVillageGateTopObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBigWoodPlatform2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBigWoodPlatform2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBigWoodPlatform2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDHouseTallBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHouseTallBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHouseTallBackgroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHouseSmallBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHouseSmallBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHouseSmallBackgroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHouseTallForegroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHouseTallForegroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHouseTallForegroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHouseObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHouseObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHouseObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBlackSpaceObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlackSpaceObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlackSpaceObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCloudsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCloudsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCloudsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDFullMoonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFullMoonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFullMoonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDKnightMaleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDKnightMaleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDKnightMaleObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDShotgunObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShotgunObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShotgunObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBossIconObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBossIconObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBossIconObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBullet5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet5Objects3.length = 0;

gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
